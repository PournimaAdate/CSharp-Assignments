using System;
using NUnit.Framework;
using ServiceProject;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;

namespace Tests
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
             
        }

        [Test]
        [Ignore("Assignment 1 for XPath")]
        public void Test1()
        {
          /*  TestClass tc=new TestClass();
            tc.testMethod();*/
             IWebDriver driver=new FirefoxDriver();
        FirefoxDriverService service = FirefoxDriverService.CreateDefaultService(@"D:\C# Training\BrowserCommands\CommandsProject\drivers");
        

             driver.Navigate().GoToUrl("https://www.toolsqa.com/automation-practice-form/");

             driver.FindElement(By.XPath("//input[@name='firstname']")).SendKeys("abc");
             driver.FindElement(By.XPath("//*[contains(@name,'lastname')]")).SendKeys("abc");
             driver.FindElement(By.XPath("//*[contains(text(),'Partial Link')]")).Click();
             //driver.FindElement(By.XPath("//*[@id='submit' or @name='button']")).Click();
             driver.FindElement(By.XPath("//input[@name='profession' and @type='checkbox' and @value='Automation Tester']")).Click();
             driver.FindElement(By.XPath("//a[starts-with(@href,'http://toolsqa.com/automation-practice-table/')]//ancestor::a[1]")).Click();
             driver.Navigate().Back();
             driver.FindElement(By.XPath("//div[@class='control-group']/child::input[2][1]")).Click();
             driver.FindElement(By.XPath("//li[@class='current']//preceding::a[1]")).Click();
              driver.Navigate().Back();
             driver.FindElement(By.XPath("//input[@id='exp-1']//following-sibling::input[1]")).Click();
             
             driver.FindElement(By.XPath("//*[@id='main']//descendant::a[3]")).Click();
             driver.Quit();



        }

         [Test]

         //Assignment 2 for Radio Button and Checkbox
        public void Test2()
        {
            SelectionClass sc=new SelectionClass();
            sc.RadioMethod();
            sc.CheckBoxMethod();
        }
    }
}