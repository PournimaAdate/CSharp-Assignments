﻿using System;

using ServiceProject;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using System.Drawing;


namespace ServiceProject
{
    public class SelectionClass
    {
        IWebDriver driver=new FirefoxDriver();
        FirefoxDriverService service = FirefoxDriverService.CreateDefaultService(@"D:\C# Training\BrowserCommands\CommandsProject\drivers");

        public void RadioMethod()
        {
        
        driver.Navigate().GoToUrl("http://demo.guru99.com/test/radio.html");
        IWebElement radio1=driver.FindElement(By.XPath("//input[@id='vfb-7-1']"));
        IWebElement radio2=driver.FindElement(By.XPath("//input[@id='vfb-7-2']"));
        Console.WriteLine("Radio button 1 : "+radio1.Text);
        Console.WriteLine("Radio button 1 : "+radio2.Text);

        string value = "";
        bool isChecked = radio1.Selected;
        if(isChecked )
        {
        value=radio1.Text;
        }
        
        {
        radio2.Click();
        value=radio2.Text;
        }
        }


        public void CheckBoxMethod()
        {
        IWebElement checkBox1=driver.FindElement(By.XPath("//input[@id='vfb-6-0']"));
        IWebElement checkBox2=driver.FindElement(By.XPath("//input[@id='vfb-6-1']"));

        checkBox1.Click();
        
        if(checkBox1.Selected)
        { Console.WriteLine("Checkbox 1 is checked!");
            string name1=checkBox1.Text;
           
            Console.WriteLine("\nName of checked checkbox 1: "+name1);
            

        }
        
            
             checkBox2.Click();
            string name2=checkBox2.Text;
            
            Console.WriteLine("Unchecked checkbox is checked!");
            Console.WriteLine("\nName of checked checkbox 2: "+name2);
           
        


        }


        
        }
    }

