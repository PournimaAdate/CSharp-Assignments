using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
namespace AdvanceDotNet
{
    class WordCount
    {
        string inputString;
        int countWord=0;
        public void InputString()
        {
            Console.WriteLine("\nEnter String: ");
            inputString=Console.ReadLine();
        }

        public void GetCount()
        {
            InputString();
            for(int i=0;i<inputString.Length;++i)
            {
            char currentChar=inputString[i];
                if(Char.IsWhiteSpace(currentChar))
                {
                countWord++;
                }
            }
            Console.WriteLine("\nNumber of words in string: "+(countWord+1));
            Console.WriteLine("\n--------------------------------------\n");
        }
    }
}