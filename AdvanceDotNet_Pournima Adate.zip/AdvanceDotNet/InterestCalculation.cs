using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
namespace AdvanceDotNet
{
    public abstract class Result  
    {  
    public abstract void Calculation();  
    }  

    public interface AcceptInput
    {
    public void GetValues(double principal, int tenure, double interest);
  
    }

    class InterestCalculation : Result, AcceptInput   //Inherit interface and abstract class
    {
        double principalValue;
        int tenureValue;
        double interestRate;
        double iRate;
        double result;

        public void GetValues(double principal, int tenure, double interest) //Interface method definition
        {
            Console.WriteLine("Enter Principal Amount: ");
            string pValue=Console.ReadLine();
            Double.TryParse(pValue, out principalValue);
            principal=principalValue;

            Console.WriteLine("Enter Tenure in years: ");
            string tValue=Console.ReadLine();
            Int32.TryParse(tValue, out tenureValue);
            tenure=tenureValue;

            Console.WriteLine("Enter Interest in % per year: ");
            string iValue=Console.ReadLine();
            Double.TryParse(iValue, out interestRate);
            interest=interestRate;

        }

        public override  void Calculation()
        {
            GetValues(principalValue, tenureValue, interestRate);
            iRate=interestRate/100;
            result=principalValue*tenureValue*iRate;
            Console.WriteLine("\nPrincipal: "+principalValue+"\nTenure: "+tenureValue+"\nInterest: "+interestRate);
            Console.WriteLine("\nCalclulated Interest rate is: "+result);
            
        }

        
    }
}