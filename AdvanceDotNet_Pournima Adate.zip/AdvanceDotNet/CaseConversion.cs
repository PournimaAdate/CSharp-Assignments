using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Globalization;
namespace AdvanceDotNet
{
    class CaseConversion
    {
        string[] pascalInput=new string[100];
      //  string str="";
       // int n;      
        
        public void ConvertToPascal()
        {
            
           // Get string from user
            string[] inputTitle=new string[100];
            Console.WriteLine("Enter string to be converted to Pascal case: \n");
            string inputString=Console.ReadLine();

            char[] charArray=new char[inputString.Length];
            bool wordStart=true;

            Console.WriteLine("\nString converted to Pascal case: \n");

            //Conversion to Pascal case
            for(int k=0;k<inputString.Length;++k)
            {
                char thisChar=inputString[k];

                //if current char is whitespace, set wordStart to true, if word start is true, convert first letter to upper case
                if(Char.IsLetter(thisChar))  
                {
                    if(wordStart)
                    {
                        wordStart=false;
                        thisChar=Char.ToUpper(thisChar);
                    }
                    else
                    {
                        thisChar=Char.ToLower(thisChar);
                    }
                }
                else if(Char.IsWhiteSpace(thisChar))
                {
                    wordStart=true;
                }
                charArray[k]=thisChar; //store in charArray
              
            }
           
           //convert charecter array to string, remove whitespaces and display
           string charstring=new string(charArray);
           Console.WriteLine(charstring.Replace(" ", String.Empty));
           Console.WriteLine("\n--------------------------------------\n");
           
        }

        public void ConvertToCamel()
        {
            //get string input from user
            string[] inputCamel=new string[100];  
            Console.WriteLine("\nEnter string to convert into Camel case:\n");
            string camelString=Console.ReadLine();

            char[] charCamel=new char[camelString.Length];
            bool camelStart=true;

            Console.WriteLine("\nString converted to Camel case: \n");
           
             //Conversion to Camel case
            for(int i=0;i<camelString.Length;++i)
            {
                char thisLetter=camelString[i];

                //if current char is whitespace, set wordStart to true, if word start is true, convert first letter to upper case
                if(Char.IsLetter(thisLetter))  
                {
                    if(camelStart)
                    {
                        camelStart=false;
                        thisLetter=Char.ToLower(thisLetter);
                    }
                    else
                    {
                        thisLetter=Char.ToUpper(thisLetter);
                    }
                }
                else if(Char.IsWhiteSpace(thisLetter))
                {
                    camelStart=true;
                }
                charCamel[i]=thisLetter; //store in charArray
            }

            string convString=new string(charCamel);
            Console.WriteLine(convString.Replace(" ", String.Empty));
            Console.WriteLine("\n--------------------------------------\n");
        }

        public void ConvertToTitle()
        {
            string[] inputTitle1=new string[100];
            Console.WriteLine("Enter string to be converted to Title case: \n");
            string inputTitleString=Console.ReadLine();

            char[] charTitleArray=new char[inputTitleString.Length];
            bool wordTitle=true;

            Console.WriteLine("\nString converted to Title case: \n");

            //Conversion to Pascal case
            for(int j=0;j<inputTitleString.Length;++j)
            {
                char thisTitleChar=inputTitleString[j];

                //if current char is whitespace, set wordStart to true, if word start is true, convert first letter to upper case
                if(Char.IsLetter(thisTitleChar))  
                {
                    if(wordTitle)
                    {
                        wordTitle=false;
                        thisTitleChar=Char.ToUpper(thisTitleChar);
                    }
                    else
                    {
                        thisTitleChar=Char.ToLower(thisTitleChar);
                    }
                }
                else if(Char.IsWhiteSpace(thisTitleChar))
                {
                        wordTitle=true;
                }
                charTitleArray[j]=thisTitleChar; //store in charArray
              
            }
           
            string convString=new string(charTitleArray);
            Console.WriteLine(convString);
            Console.WriteLine("\n--------------------------------------\n");
           
        }
           
    }
}

