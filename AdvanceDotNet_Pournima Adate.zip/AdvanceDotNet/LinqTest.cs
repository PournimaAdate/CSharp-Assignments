using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
namespace AdvanceDotNet
{
    class LinqTest
    {
       

    public void LinqMethod()
    {
       string[] names=new string[100];
       // string[] names=new string[100];
        int n;
        Console.WriteLine("Enter number of elements: ");
        string number=Console.ReadLine();
        Int32.TryParse(number, out n);

        for(int i=0;i<=n;i++)
        { names[i]=Console.ReadLine();   }

     var myLinq= (from name in names where name.Contains('p') select name).ToString();
     Console.WriteLine("Elements containing P are: ");

     for(int j=0;j<n;j++)
     {
     var name=myLinq[j];
     Console.WriteLine(name);
     }
        
    }

    public void LinqInt()
    {
        Console.WriteLine("\n");
        int[] numbers = { 5, 4, 1, 3, 9, 8};  
var num =from n in numbers orderby n select n;  
Console.WriteLine("Sorted Numbers: ");
foreach (var i in num)  
{  
    Console.WriteLine(i.ToString() );  
}

    }
}
}

