using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Collections;


namespace AdvanceDotNet
{
    class DistinctWord
    {
        string inputString;
        List<string> listString;
        int dCount=0;
        List<string> result = new List<string>();

        public void GetInput()
        {
            Console.WriteLine("\nEnter String: ");  //Get input string
            inputString=Console.ReadLine();
        }

        public void DistinctCount()
        {
            GetInput();
            listString = inputString.Split(' ').ToList(); //Convert string to list
          
            for (int i = 0; i < listString.Count; i++)
            {            
                bool duplicate = false;
                for (int z = 0; z < i; z++)
                    {
                    if (listString[z] == listString[i])  //compare input list items
                        {
                        duplicate = true;
                        break;
                        }
                    }
            
                if (!duplicate)
                {
                result.Add(listString[i]);  // If unique, add to result.
                dCount++;
                }
            }

            Console.WriteLine("\nUnique words count: "+dCount);
            Console.WriteLine("\nUnique words are: ");
            for (int k = 0; k < result.Count; k++)
            {
                Console.WriteLine(result[k]);
            }
                    
        }
    }
}
