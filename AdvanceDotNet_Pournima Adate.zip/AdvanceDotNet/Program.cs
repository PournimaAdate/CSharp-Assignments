﻿using System;

namespace AdvanceDotNet
{
    class Program
    {
        static void Main(string[] args)
        {
            int caseChoice;
            int choice;
            
            do
            {
            //Console.WriteLine("\nEnter 0 to exit.\n");
            Console.WriteLine("\n1. Convert the string to Title Case and Camel case.\n2. Count the no of words in a string.\n3. Count the distinct words in a string.\n4. Find the second maximum number from the list of  integers\n5. Create the delegate and use the delegate in a program.\n6. Accept Principal, interest rate and tenure and calculate the interest rate\n7. Enter 0 to exit");
            Console.WriteLine("Enter assignment number: ");
            string choiceNum=Console.ReadLine();
            Int32.TryParse(choiceNum, out choice);

            switch(choice)
            {

            case 5:
            Console.WriteLine("\n--------Test Delegates--------");       
            TestDel del1=new TestDel(TestDelegates.AddNum);
            del1();
            Console.WriteLine("Addition: "+TestDelegates.DisplayAdd());
            break;
            
            case 1: 
            Console.WriteLine("\n--------String Case Conversion--------");       
            CaseConversion cc=new CaseConversion();
            do {
            Console.WriteLine("\n1. Convert to Pascal Case\n2. Convert to Camel Case\n3. Convert to Title case\n4. Press 0 to Exit");
            Console.WriteLine("Enter Case Conversion Option: ");
            string option=Console.ReadLine();
            Int32.TryParse(option, out caseChoice);
            switch (caseChoice)
                {
                    case 1:
                    cc.ConvertToPascal(); break;
                    case 2:
                    cc.ConvertToCamel();  break;
                    case 3:
                    cc.ConvertToTitle();  break;
                    default: 
                    Console.WriteLine("Invalid Option"); break;
                }
                } while(caseChoice!=0);
            break;

            case 2:
            Console.WriteLine("\n--------Count Words In String--------");       
            WordCount wCount=new WordCount();
            wCount.GetCount(); 
            break;   

            case 3:
            Console.WriteLine("\n--------Count Distinct Words In String--------");       
            DistinctWord dw=new DistinctWord();
            dw.DistinctCount();
            break;
            
            case 4:
            Console.WriteLine("\n--------Second Max Number using LinQ--------");       
            MaxLinq ml=new MaxLinq();
            ml.GetSecondMax();
            break;

            case 6:
            Console.WriteLine("\n--------Interest Rate Calculation--------");  
            InterestCalculation ic=new InterestCalculation();
            //ic.Calculation();     
            Result rs;
            rs=new InterestCalculation();
           // ic.GetValues(principal,tenure,interest);
            rs.Calculation();
            break;

            default:
            Console.WriteLine("Invalid Choice");
            break;
            }
            }while(choice!=0);

           Console.ReadLine();
        }
    }
}
