using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
namespace AdvanceDotNet
{
    class MaxLinq
    {
        List<int> numbers = new List<int>();
        List<int> result = new List<int>();
        string num,getElement;
        int elements, getItem;

        public void InputList()
        {
            Console.WriteLine("Enter number of elements you want to add in array: ");
            num=Console.ReadLine();
            Int32.TryParse(num, out elements);

            for(int i=0;i<elements;i++)
            {
                Console.WriteLine("Enter element " + (i + 1));
                getElement = Console.ReadLine();
                Int32.TryParse(getElement,out getItem);
                numbers.Add(getItem);
            }
            Console.WriteLine("\nElements in List are: ");
            foreach (var item in numbers)
            {
                Console.WriteLine(item);
            }

        }

        public void GetSecondMax()
        {
            InputList();
            numbers.Remove(numbers.Max());
            
            int secondMax = (from num in numbers select num).Max(); //LinQ query for maximum
            Console.WriteLine("\nSecond Maximum No: "+secondMax);
           
        }
    }
}