using System;
delegate int TestDel();  //Declared delegate
namespace AdvanceDotNet
{
    class TestDelegates
    {
      static int num1,addNum;
      static string getnum1;

        public static int AddNum()  //Method to perform addition of 10 numbers
        {
            Console.WriteLine("\nEnter 10 Numbers: ");  
            for (int i = 0; i <= 9; i++)
            {
                Console.WriteLine("Enter Number " + (i + 1));
                getnum1 = Console.ReadLine();
                Int32.TryParse(getnum1,out num1);
                addNum += num1;               
            }
            return addNum;
        }

        public static int DisplayAdd()
        {
        return addNum;
        
        }
    }
}